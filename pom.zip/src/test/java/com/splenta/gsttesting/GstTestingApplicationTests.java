package com.splenta.gsttesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GstTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
