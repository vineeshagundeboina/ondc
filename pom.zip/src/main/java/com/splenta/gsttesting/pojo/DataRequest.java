package com.splenta.gsttesting.pojo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter

public class DataRequest {

	private String Data;

}
