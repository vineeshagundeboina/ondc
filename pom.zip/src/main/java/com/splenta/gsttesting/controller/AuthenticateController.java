package com.splenta.gsttesting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.gsttesting.pojo.AuthenticateRequest;
import com.splenta.gsttesting.service.AuthService;

@RestController
@RequestMapping("api/auth")
@CrossOrigin(origins = "*")
public class AuthenticateController {

	@Autowired
	private AuthService authService;

	@GetMapping("/")
	public String getIndex() {
		return "Welcome to GST Testing";
	}

	@PostMapping("/authenticate")
	public ResponseEntity<?> authenticate(@RequestBody AuthenticateRequest authenticateRequest) {

		return ResponseEntity.ok().body(authService.autheticateUser(authenticateRequest));
	}

}
