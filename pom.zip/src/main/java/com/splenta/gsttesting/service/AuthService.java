package com.splenta.gsttesting.service;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.splenta.gsttesting.pojo.AuthenticateRequest;
import com.splenta.gsttesting.pojo.DataRequest;
import com.splenta.gsttesting.pojo.JsonData;

@Service
public class AuthService {

	@Value("${publicKey}")
	private String publicKey;

	public String autheticateUser(AuthenticateRequest authenticateRequest) {

		try {

			// Base64 encryption
			UUID uuid = UUID.randomUUID();
			String randomString = uuid.toString().replace("-", "");
			Base64.Encoder encoder = Base64.getEncoder();
			String uuidEncodedFormat = encoder.encodeToString(randomString.substring(0, 32).getBytes());
			authenticateRequest.setAppKey(uuidEncodedFormat);

			JsonData jsonData = new JsonData();
			jsonData.setAppKey(authenticateRequest.getAppKey());
			jsonData.setForceRefreshAccessToken(authenticateRequest.isForceRefreshAccessToken());
			jsonData.setPassword(authenticateRequest.getPassword());
			jsonData.setUserName(authenticateRequest.getUserName());
			System.out.println("jsonData: " + jsonData);
			System.out.println("ENCODED APPKEY:  " + uuidEncodedFormat);
			System.out.println(
					"=======Authenticate Request load=======================================================================\n"
							+ authenticateRequest.toString()
							+ "\n=======================================================================================================\n");

			String base64EncodedData = encoder.encodeToString(jsonData.toString().getBytes());

			// String result =
			// "ewogICAgIlVzZXJOYW1lIjogIkFMMDAxIiwKICAgICJQYXNzd29yZCI6ICJBbGFua2l0QDEyMyIsCiAgICAiQXBwS2V5IjogIk5UbGhNakkxTnpVdE4yUTVNeTAwWXpWaExUbGtPVEF0T1dZM1pXVTBNV1EyTmpNNCIsCiAgICAiRm9yY2VSZWZyZXNoQWNjZXNzVG9rZW4iOiB0cnVlCn0=";
//			System.out.println(
//					"=======Authenticate Request BASE64 ENCRYPTON=======================================================================\n"
//							+ base64EncodedData.toString()
//							+ "\n=======================================================================================================\n");

			// System.out.println("encode: " + enc);

			// Base64.Decoder decoder = Base64.getDecoder();
			// String req = new String(decoder.decode(enc));
			// System.out.println("dec: " + req);
			String encodedMessage = encryptWithPublicKey(base64EncodedData, publicKey);


//			/// encryption with public key
//			Cipher encryptCipher = Cipher.getInstance("RSA");
//			encryptCipher.init(Cipher.ENCRYPT_MODE, pkey);
//			byte[] secretMessageBytes = base64EncodedData.getBytes(StandardCharsets.UTF_8);
//			byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);
//			String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);

			System.out.println("\n" + encodedMessage + "\n");

			// external api consumption
			WebClient client = WebClient.create();

			// Define the request headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Ocp-Apim-Subscription-Key", "AL1S2k5m3F9P2A7S0x");
			headers.set("Gstin", "07AGAPA5363L002");
			DataRequest drequest = new DataRequest();
			drequest.setData(encodedMessage);

			System.out.println(drequest);
			// Send the POST request
			client.post().uri("https://developers.eraahi.com/eInvoiceGateway/eivital/v1.04/auth")
					.headers(httpHeaders -> httpHeaders.addAll(headers)).body(BodyInserters.fromValue(drequest))
					.retrieve().bodyToMono(String.class).subscribe(responseBody -> {
						// System.out.println("responseBody: " + responseBody);
					});
		} catch (Exception e) {
			System.out.println("exception : " + e);
		}
		return "";

	}

	public static String encryptWithPublicKey(String data, String publicKeyString) throws Exception {
		// Convert the public key string to a PublicKey object
		PublicKey publicKey = getPublicKeyFromString(publicKeyString);

		// Perform the encryption
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));

		// Return the Base64-encoded encrypted string
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}

	private static PublicKey getPublicKeyFromString(String publicKeyString) throws Exception {
		byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyString);
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		return keyFactory.generatePublic(keySpec);
	}
}
