package com.splenta.neoledger.models.masters;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "CompanyRegion")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class CompanyRegion extends BaseEntity {

	private String CompanyRegionName;
	private String CompanyRegionCode;

}
