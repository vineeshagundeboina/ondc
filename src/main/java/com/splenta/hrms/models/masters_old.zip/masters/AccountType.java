package com.splenta.neoledger.models.masters;

public enum AccountType {
	
	BANK,CASH

}
