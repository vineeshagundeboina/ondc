package com.splenta.neoledger.models.masters;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Journal extends BaseEntity {
	
	private Date transactionDate;
	private String transactionRef;
	private String transactionAccount;
	private BigDecimal DebitAmount;
	private BigDecimal CreditAmount;
	

}
