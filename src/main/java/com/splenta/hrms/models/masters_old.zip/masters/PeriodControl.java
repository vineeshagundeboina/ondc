package com.splenta.neoledger.models.masters;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class PeriodControl extends BaseEntity {
	
	@ManyToOne
	private Organization organization;
	
	private String periodStatus;
	
	@ManyToOne
	private Period period;
	

}
