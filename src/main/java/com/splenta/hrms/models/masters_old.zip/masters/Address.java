package com.splenta.neoledger.models.masters;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Cacheable
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Address extends BaseEntity {

	@Column
	public String line1;

	@Column
	public String line2;

	@Column
	public String city;

	@Column
	public String pincode;

	@ManyToOne
	public State state;

	@Column
	public String label;

	@Column(columnDefinition = "float8 default 0.0")
    private double latitude;

    @Column(columnDefinition = "float8 default 0.0")
    private double longitude;

	@ManyToOne
	public Country country;

//	@ManyToOne
//	public Company company;


	public String landmark;

}
