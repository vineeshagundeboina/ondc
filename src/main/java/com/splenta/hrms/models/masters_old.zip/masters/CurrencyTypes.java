package com.splenta.neoledger.models.masters;

public enum CurrencyTypes {
	
	INR,USD

}
