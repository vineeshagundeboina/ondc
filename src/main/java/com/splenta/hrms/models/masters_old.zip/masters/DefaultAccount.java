package com.splenta.neoledger.models.masters;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class DefaultAccount extends BaseEntity {

	private String productExpense;
	private String productRevenue;
	private String invoicePriceVariance;
	private String productCOGS;
	private String customerReceivablesNo;
	private String customerPrepayment;
	private String vendorLiability;
	private String vendorServiceLiability;
	private String vendorPrepayment;
	private String paymentDiscountExpense;
	private String paymentDiscountRevenue;
	private String withholdingAccount;
	private String employeePrepayments;
	private String employeeExpenses;
	private String projectAsset;
	private String taxExpense;
	private String taxLiability;
	private String taxReceivables;
	private String taxDue;
	private String dueTransAcct;
	private String taxCredit;
	private String creditTransAcct;
	private String bankInTransit;
	private String bankExpense;
	private String bankInterestRevenue;
	private String bankInterestExpense;
	private String bankSettlementGain;
	private String bankSettlementLoss;
	private String badDebtExpenseAccount;
	private String badDebtRevenueAccount;
}
