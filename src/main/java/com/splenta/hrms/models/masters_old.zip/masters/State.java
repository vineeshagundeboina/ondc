package com.splenta.neoledger.models.masters;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Cacheable
public class State extends BaseEntity {

	@Column
	public String stateName;

	@Column
	public String stateCode;

	@ManyToOne
	public Country country;

	public Boolean isTaxZone = false;

	public Boolean isUT = false;

}
