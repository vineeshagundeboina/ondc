package com.splenta.neoledger.models.masters;

import java.math.BigDecimal;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Ledger extends BaseEntity {
	
		private String ledgerName;
		private String typeOfAccount;
		private BigDecimal DebitAmount;
		private BigDecimal CreditAmount;
		private BigDecimal 	NetMovement;

}
