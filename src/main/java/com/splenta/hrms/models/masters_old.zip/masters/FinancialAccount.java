package com.splenta.neoledger.models.masters;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class FinancialAccount extends BaseEntity {

	private String faName;
	
	private CurrencyTypes currencyType;
	
	private AccountType accountType;
	
	@ManyToOne
	private Address address;
	
	
	private BigDecimal creditLimit;
	private BigDecimal initialBalance;
	
	@ManyToOne
	private BankAccount bankAccount;
	
	
	
	
}
