package com.splenta.neoledger.models.masters;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Organization extends BaseEntity {

	private String orgCode;
	private String orgName;
	private String orgDescription;
	private String orgCurrency;
	
	//@Column("")
	private boolean isLegal;
	@ManyToOne
	private Calendar calendar;
	
	@ManyToOne
	private Company company;

}
