package com.splenta.neoledger.models.masters;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.splenta.neoledger.common.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "Company")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Company extends BaseEntity {

	@Column(unique = true)
	private String companyName;

	private String companyLocation;

	private String companyPanNumber;

	private String companyAddress1;

	private String companyAddress2;

	private String companyPhone;

	private String companyMail;

	private String pincode;
	
	private String accountNumber;

	@ManyToOne
	private State state;

	@ManyToOne
	private Country country;

}
