package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.CompanyRegion;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/companyregion")
@Tag(name = "CompanyRegion", description = "APIs for companyregion related operations")
public class CompanyRegionController extends GenericController<CompanyRegion> {

	public CompanyRegionController(GenericRepository<CompanyRegion> repository) {
		super(repository);
	}

}
