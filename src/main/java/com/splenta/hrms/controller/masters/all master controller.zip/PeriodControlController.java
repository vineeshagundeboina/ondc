package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.PeriodControl;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/periodcontrol")
@Tag(name = "PeriodControl", description = "APIs for PeriodControl related operations")
public class PeriodControlController extends GenericController<PeriodControl> {

	public PeriodControlController(GenericRepository<PeriodControl> repository) {
		super(repository);
	}

}
