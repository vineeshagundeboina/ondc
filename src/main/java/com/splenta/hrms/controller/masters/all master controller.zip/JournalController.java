package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Journal;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/journal")
@Tag(name = "Journal", description = "APIs for Journal related operations")
public class JournalController extends GenericController<Journal> {

	public JournalController(GenericRepository<Journal> repository) {
		super(repository);
	}

}
