//package com.splenta.neoledger.controller.masters;
//
//
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.splenta.neoledger.common.GenericController;
//import com.splenta.neoledger.common.GenericRepository;
//import com.splenta.neoledger.models.masters.FiscalCalendar;
//
//import io.swagger.v3.oas.annotations.tags.Tag;
//
//@RestController
//@RequestMapping("/api/fiscalcalendar")
//@Tag(name = "FiscalCalendar", description = "APIs for FiscalCalendar related operations")
//public class FiscalCalendarController extends GenericController<FiscalCalendar> {
//
//	public FiscalCalendarController(GenericRepository<FiscalCalendar> repository) {
//		super(repository);
//	}
//
//}
