package com.splenta.neoledger.controller.masters;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.models.masters.LedgerLine;
import com.splenta.neoledger.repos.masters.LedgerLineRepo;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/ledgerline")
@CrossOrigin(origins = "*")
@Tag(name = "LedgerLine", description = "APIs for Ledger Lines related operations")
public class LedgerLineController {

	@Autowired
	private LedgerLineRepo ledgerLineRepo;

	@GetMapping("/getLinesByLedgerId/{ledgerId}")
	public ResponseEntity<?> getLedgerLinesByLedgerId(@PathVariable("ledgerId") UUID ledgerId) {

		System.out.println("ledgerId:" + ledgerId + " ");

		return ResponseEntity.ok().body(ledgerLineRepo.findByLedgerId(ledgerId));
	}

	@PostMapping("/createLedgerLine")
	public ResponseEntity<?> createLedgerLine(@RequestBody LedgerLine ledgerLine) {

		return ResponseEntity.ok().body(ledgerLineRepo.save(ledgerLine));
	}
	
	@PutMapping("/updateLedgerLine/{ledgerLineId}")
	public ResponseEntity<?> updateLedgerLine(@RequestBody LedgerLine ledgerLine,@PathVariable("ledgerLineId") UUID ledgerLineId) {

		
		return ResponseEntity.ok().body(ledgerLineRepo.save(ledgerLine));
	}
}
