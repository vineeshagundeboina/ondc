package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Year;

import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api/year")
@Tag(name = "Year", description = "APIs for Year related operations")
public class YearController extends GenericController<Year> {

	public YearController(GenericRepository<Year> repository) {
		super(repository);
	}

}
