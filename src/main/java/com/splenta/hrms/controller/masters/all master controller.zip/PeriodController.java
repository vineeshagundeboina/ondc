package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Period;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/period")
@Tag(name = "Period", description = "APIs for Period related operations")
public class PeriodController extends GenericController<Period> {

	public PeriodController(GenericRepository<Period> repository) {
		super(repository);
	}

}
