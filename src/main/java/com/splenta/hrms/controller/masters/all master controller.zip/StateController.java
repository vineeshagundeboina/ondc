package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.State;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/state")
@Tag(name = "State", description = "APIs for State related operations")
public class StateController extends GenericController<State> {

	public StateController(GenericRepository<State> repository) {
		super(repository);
	}

}
