package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Currency;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/currency")
@Tag(name = "Currency", description = "APIs for Currency related operations")

public class CurrencyController extends GenericController<Currency>{

	public CurrencyController(GenericRepository<Currency> repository) {
		super(repository);
		// TODO Auto-generated constructor stub
	}

}
