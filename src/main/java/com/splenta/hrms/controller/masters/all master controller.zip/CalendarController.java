package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Calendar;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/calendar")
@Tag(name = "Calendar", description = "APIs for Calendar related operations")
public class CalendarController extends GenericController<Calendar> {

	public CalendarController(GenericRepository<Calendar> repository) {
		super(repository);
	}

}
