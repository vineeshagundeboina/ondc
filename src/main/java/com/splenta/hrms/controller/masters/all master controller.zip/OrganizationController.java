package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Branch;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/organization")
@Tag(name = "Organization", description = "APIs for Organization related operations")
public class OrganizationController extends GenericController<Branch>{

	public OrganizationController(GenericRepository<Branch> repository) {
		super(repository);
	}

}
