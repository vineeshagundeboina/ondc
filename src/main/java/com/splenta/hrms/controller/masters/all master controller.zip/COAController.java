package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.COA;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/coa")
@Tag(name = "COA", description = "APIs for COA related operations")
@CrossOrigin(origins = "*")
public class COAController extends GenericController<COA> {

	public COAController(GenericRepository<COA> repository) {
		super(repository);
	}

}
