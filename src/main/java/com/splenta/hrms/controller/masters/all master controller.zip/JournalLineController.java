package com.splenta.neoledger.controller.masters;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.JournalLine;
import com.splenta.neoledger.repos.masters.JournalLineRepo;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/journalline")
@Tag(name = "Journal Line", description = "APIs for Journal Line related operations")
public class JournalLineController extends GenericController<JournalLine> {

	public JournalLineController(GenericRepository<JournalLine> repository) {
		super(repository);
	}
	
	
	@Autowired
	private JournalLineRepo journalLineRepo;

	@GetMapping("/getLinesByJournalId/{journalid}")
	public ResponseEntity<?> getJournalLinesByLedgerId(@PathVariable("journalid") UUID journalid) {

		System.out.println("journalid:" + journalid + " ");

		return ResponseEntity.ok().body(journalLineRepo.findByJournalId(journalid));
	}

	@PostMapping("/createJournalLine")
	public ResponseEntity<?> createJournalLine(@RequestBody JournalLine journalLine) {

		return ResponseEntity.ok().body(journalLineRepo.save(journalLine));
	}
	
	@PutMapping("/updateJournalLine/{journalLineId}")
	public ResponseEntity<?> updateJournalLine(@RequestBody JournalLine journalLine,@PathVariable("journalLineId") UUID journalLineId) {

		
		return ResponseEntity.ok().body(journalLineRepo.save(journalLine));
	}

}
