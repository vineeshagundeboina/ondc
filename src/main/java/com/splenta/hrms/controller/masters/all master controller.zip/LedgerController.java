package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Ledger;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/ledger")
@Tag(name = "Ledger", description = "APIs for Ledger related operations")
public class LedgerController extends GenericController<Ledger> {

	public LedgerController(GenericRepository<Ledger> repository) {
		super(repository);
	}

}
