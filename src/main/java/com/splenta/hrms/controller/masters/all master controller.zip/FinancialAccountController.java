package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.FinancialAccount;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/financialaccount")
@Tag(name = "FinancialAccount", description = "APIs for FinancialAccount related operations")
public class FinancialAccountController  extends GenericController<FinancialAccount> {

	public FinancialAccountController(GenericRepository<FinancialAccount> repository) {
		super(repository);
	}

}
