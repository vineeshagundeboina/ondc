package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.BankAccount;

import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api/bankaccount")
@Tag(name = "BankAccount", description = "APIs for Bankaccount related operations")
public class BankAccountController extends GenericController<BankAccount> {

	public BankAccountController(GenericRepository<BankAccount> repository) {
		super(repository);
	}

}
