package com.splenta.neoledger.controller.masters;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.splenta.neoledger.common.GenericController;
import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.models.masters.Company;

import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api/company")
@Tag(name = "Company", description = "APIs for company related operations")
public class CompanyController extends GenericController<Company> {

	public CompanyController(GenericRepository<Company> repository) {
		super(repository);
	}

}
