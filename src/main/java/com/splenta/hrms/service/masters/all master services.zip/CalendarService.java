package com.splenta.neoledger.service.masters;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.Calendar;

public class CalendarService extends GenericService<Calendar>{

	public CalendarService(GenericRepository<Calendar> repository) {
		super(repository);
	}

}
