package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Repository;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.COA;

@Repository
public class COAService extends GenericService<COA> {

	public COAService(GenericRepository<COA> repository) {
		super(repository);
	}

}
