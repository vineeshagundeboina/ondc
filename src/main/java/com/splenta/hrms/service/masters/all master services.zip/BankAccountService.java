package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Service;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.BankAccount;

@Service
public class BankAccountService extends GenericService<BankAccount>{

	public BankAccountService(GenericRepository<BankAccount> repository) {
		super(repository);
	}

}
