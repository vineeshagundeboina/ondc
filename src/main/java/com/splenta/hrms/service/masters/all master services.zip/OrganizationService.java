package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Service;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.Branch;

@Service
public class OrganizationService extends GenericService<Branch>{

	public OrganizationService(GenericRepository<Branch> repository) {
		super(repository);
	}

}
