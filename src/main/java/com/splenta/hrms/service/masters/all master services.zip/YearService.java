package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Service;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.Year;

@Service
public class YearService extends GenericService<Year> {

	public YearService(GenericRepository<Year> repository) {
		super(repository);
	}

}
