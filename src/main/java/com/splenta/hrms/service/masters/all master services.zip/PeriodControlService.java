package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Service;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.PeriodControl;

@Service
public class PeriodControlService extends GenericService<PeriodControl> {

	public PeriodControlService(GenericRepository<PeriodControl> repository) {
		super(repository);
	}

}
