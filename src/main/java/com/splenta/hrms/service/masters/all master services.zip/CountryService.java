package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Service;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.Country;

@Service
public class CountryService extends GenericService<Country>{

	public CountryService(GenericRepository<Country> repository) {
		super(repository);
	}

}
