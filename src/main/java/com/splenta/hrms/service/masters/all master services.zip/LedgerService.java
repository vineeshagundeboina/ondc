package com.splenta.neoledger.service.masters;

import org.springframework.stereotype.Service;

import com.splenta.neoledger.common.GenericRepository;
import com.splenta.neoledger.common.GenericService;
import com.splenta.neoledger.models.masters.Ledger;

@Service
public class LedgerService extends GenericService<Ledger> {

	public LedgerService(GenericRepository<Ledger> repository) {
		super(repository);
	}

}
